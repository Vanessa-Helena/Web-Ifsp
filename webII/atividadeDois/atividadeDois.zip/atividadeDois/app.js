const atividadeDois = require('./atividadeDois');

//console.log(atividadeDois);

console.log(atividadeDois.areaPerimetro());